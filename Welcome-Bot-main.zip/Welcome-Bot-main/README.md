# Index Of Contents

# [Chapter 1](https://github.com/TheCrazyCatKidz/Welcome-Bot/blob/main/Chapters/Chapter1.md) - Setting up your stripped down bot
# [Chapter 2](https://github.com/TheCrazyCatKidz/Welcome-Bot/blob/main/Chapters/Chapter2.md) - De-cluttering your stripped down bot
# [Chapter 3](https://github.com/TheCrazyCatKidz/Welcome-Bot/blob/main/Chapters/Chapter3.md) - Work In Progress

Return back to the [PS.XYZ Directory](https://github.com/TheCrazyCatKidz/PS.XYZ-Directory).

Made for the purpose of [PS.XYZ](https://platservices.xyz).
